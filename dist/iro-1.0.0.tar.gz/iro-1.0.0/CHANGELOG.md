# v1.0.0
- Project is now stable.
- This version has almost no compatibility between previous versions.

# v0.8.1
- fix inheritance error.

# v0.8.0
- `Color`, `Color256`, `ColorRGB`, `Font`, `Style` now inherits `IroElement`

# v0.6.0
- added `Iro(optimize_level=0)`
- `Style.RESET` is now public
- added styles

    `OFF_INTENSITY`
    `OFF_BOLD`
    `OFF_DIM`
    `OFF_ITALIC`
    `OFF_UNDERLINE`
    `OFF_BLINK`
    `OFF_INVERT`
    `OFF_HIDE`
    `OFF_STRIKE`

    `OFF_COLOR`
    `OFF_BG_COLOR`
    
    `OFF_OVERLINE`

# v0.5.0
- fixed `Color256` not in `__init__.all`

# v0.4.0
- fixed error on `from iro import *`

# v0.3.0
- Rename `RGBColor` to `ColorRGB`

# v0.2.0
- Allowed Iro to accept variable length arguments.

# v0.1.0
- conception